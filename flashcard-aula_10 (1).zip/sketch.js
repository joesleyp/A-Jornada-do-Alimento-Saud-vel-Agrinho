// Variáveis Globais
let telaAtual = 0; // 0: Início, 1: Fase 1, 2: Fase 2, 3: Fase 3, 4: Fim
let personagem;
let frutas = [];
let obstaculos = [];
let vida = 3;
let pontuacao = 0;
let ingredientesColetados = []; // Para armazenar o que foi pego

// Carregamento de imagens (se for usar)
// let imgPersonagem;
// let imgMaca;

function preload() {
  // Carrega as imagens aqui
  // imgPersonagem = loadImage('assets/personagem.png');
  // imgMaca = loadImage('assets/maca.png');
}

function setup() {
  createCanvas(800, 600);
  // Inicializa o personagem e outros objetos
  personagem = new Personagem();
  // ... outras inicializações de fases
}

function draw() {
  background(220); // Cor de fundo padrão

  if (telaAtual === 0) {
    desenhaTelaInicio();
  } else if (telaAtual === 1) {
    desenhaFase1Campo();
  } else if (telaAtual === 2) {
    desenhaFase2Feira();
  } else if (telaAtual === 3) {
    desenhaFase3Cozinha();
  } else if (telaAtual === 4) {
    desenhaTelaFim();
  }

  // Desenha pontuação e vida em todas as telas de jogo
  if (telaAtual > 0 && telaAtual < 4) {
    fill(0);
    textSize(20);
    text('Vida: ' + vida, 10, 30);
    text('Pontos: ' + pontuacao, 10, 60);
  }
}

function mousePressed() {
  // Gerencia cliques em botões ou interações de arrastar
  if (telaAtual === 0) {
    // Botão "Jogar"
    if (mouseX > width / 2 - 50 && mouseX < width / 2 + 50 &&
        mouseY > height / 2 && mouseY < height / 2 + 50) {
      telaAtual = 1; // Inicia o jogo
      resetGame(); // Reseta variáveis para um novo jogo
    }
  }
  // Lógica para a Fase 3 (arrastar ingredientes)
  if (telaAtual === 3) {
    // ...
  }
}

function keyPressed() {
  // Movimento do personagem
  if (telaAtual === 1 || telaAtual === 2) {
    if (keyCode === LEFT_ARROW) {
      personagem.move(-5); // Move para a esquerda
    } else if (keyCode === RIGHT_ARROW) {
      personagem.move(5); // Move para a direita
    } else if (keyCode === UP_ARROW) {
      personagem.pula(); // Pula
    }
  }
}

// Classes para Personagem, Fruta, Obstáculo, etc.
class Personagem {
  constructor() {
    this.x = width / 2;
    this.y = height - 50;
    this.tamanho = 30;
    this.velocidadeY = 0;
    this.gravidade = 0.5;
    this.noChao = true;
  }

  desenha() {
    fill(0, 100, 255); // Azul
    rect(this.x, this.y, this.tamanho, this.tamanho);
    // image(imgPersonagem, this.x, this.y, this.tamanho, this.tamanho);
  }

  move(dir) {
    this.x += dir;
    this.x = constrain(this.x, 0, width - this.tamanho); // Limita a tela
  }

  pula() {
    if (this.noChao) {
      this.velocidadeY = -10;
      this.noChao = false;
    }
  }

  atualiza() {
    this.y += this.velocidadeY;
    this.velocidadeY += this.gravidade;

    if (this.y >= height - this.tamanho) {
      this.y = height - this.tamanho;
      this.velocidadeY = 0;
      this.noChao = true;
    }
  }
}

// Funções para cada tela
function desenhaTelaInicio() {
  background(150, 200, 255); // Céu
  textAlign(CENTER, CENTER);
  textSize(48);
  fill(0);
  text('A Jornada do Alimento Saudável', width / 2, height / 3);

  // Botão Jogar
  fill(0, 200, 0);
  rect(width / 2 - 50, height / 2, 100, 50);
  fill(255);
  textSize(24);
  text('Jogar', width / 2, height / 2 + 25);

  textSize(16);
  fill(0);
  text('Use as setas para mover e pular para coletar alimentos saudáveis.', width / 2, height / 2 + 100);
}

function desenhaFase1Campo() {
  background(100, 200, 100); // Campo verde
  personagem.desenha();
  personagem.atualiza();

  // Lógica para gerar e mover frutas e obstáculos
  if (frameCount % 60 === 0) { // Gera a cada segundo
    frutas.push(new Fruta(random(width), 0, 'maca'));
    if (random(1) > 0.7) { // Chance de gerar obstáculo
      obstaculos.push(new Obstaculo(random(width), 0, 'praga'));
    }
  }

  // Atualiza e desenha frutas
  for (let i = frutas.length - 1; i >= 0; i--) {
    frutas[i].atualiza();
    frutas[i].desenha();
    if (frutas[i].y > height) { // Remove se sair da tela
      frutas.splice(i, 1);
    }
    // Verifica colisão com personagem
    if (dist(personagem.x + personagem.tamanho / 2, personagem.y + personagem.tamanho / 2,
             frutas[i].x + frutas[i].tamanho / 2, frutas[i].y + frutas[i].tamanho / 2) < (personagem.tamanho / 2 + frutas[i].tamanho / 2)) {
      pontuacao += 10;
      ingredientesColetados.push(frutas[i].tipo); // Adiciona ao inventário
      frutas.splice(i, 1);
    }
  }

  // Atualiza e desenha obstáculos
  for (let i = obstaculos.length - 1; i >= 0; i--) {
    obstaculos[i].atualiza();
    obstaculos[i].desenha();
    if (obstaculos[i].y > height) {
      obstaculos.splice(i, 1);
    }
    // Verifica colisão com personagem
    if (dist(personagem.x + personagem.tamanho / 2, personagem.y + personagem.tamanho / 2,
             obstaculos[i].x + obstaculos[i].tamanho / 2, obstaculos[i].y + obstaculos[i].tamanho / 2) < (personagem.tamanho / 2 + obstaculos[i].tamanho / 2)) {
      vida--;
      obstaculos.splice(i, 1);
      if (vida <= 0) {
        telaAtual = 4; // Fim de jogo
      }
    }
  }

  // Condição para passar de fase (ex: coletar X pontos ou X itens)
  if (pontuacao >= 50 && ingredientesColetados.length >= 5) {
    telaAtual = 2; // Passa para a Fase 2
    reiniciaFase(); // Limpa itens da fase anterior
  }
}

class Fruta {
  constructor(x, y, tipo) {
    this.x = x;
    this.y = y;
    this.tipo = tipo;
    this.tamanho = 20;
    this.velocidade = 2;
  }
  desenha() {
    if (this.tipo === 'maca') {
      fill(255, 0, 0);
      ellipse(this.x, this.y, this.tamanho, this.tamanho);
    }
    // Adicione mais tipos de frutas/vegetais
  }
  atualiza() {
    this.y += this.velocidade;
  }
}

class Obstaculo {
  constructor(x, y, tipo) {
    this.x = x;
    this.y = y;
    this.tipo = tipo;
    this.tamanho = 25;
    this.velocidade = 2.5;
  }
  desenha() {
    if (this.tipo === 'praga') {
      fill(50); // Preto
      rect(this.x, this.y, this.tamanho, this.tamanho);
    }
    // Adicione mais tipos de obstáculos
  }
  atualiza() {
    this.y += this.velocidade;
  }
}


function desenhaFase2Feira() {
  background(255, 250, 205); // Cor de feira
  personagem.desenha();
  personagem.atualiza();

  // Lógica similar à Fase 1, mas com diferentes itens e obstáculos
  // Itens: vegetais, grãos, pães integrais
  // Obstáculos: refrigerantes, doces, salgadinhos
  // ...

  // Condição para passar de fase
  if (pontuacao >= 100 && ingredientesColetados.length >= 10) {
    telaAtual = 3; // Passa para a Fase 3
    reiniciaFase();
  }
}

function desenhaFase3Cozinha() {
  background(200); // Cor de cozinha
  // Mostra os ingredientes coletados
  // Lógica para arrastar e soltar os ingredientes em um prato
  // ...

  // Um "prato" onde o jogador pode colocar os ingredientes
  fill(255);
  ellipse(width / 2, height / 2, 200, 150); // O prato

  // Exemplo de como mostrar um ingrediente coletado
  for (let i = 0; i < ingredientesColetados.length; i++) {
    // Desenhe o ingrediente em algum lugar, talvez na parte inferior da tela
    // e permita que o usuário o arraste para o prato.
    // Esta parte é mais complexa e envolve lógica de arrastar e soltar.
    fill(0, 150, 0);
    rect(50 + i * 40, height - 50, 30, 30); // Placeholder para ingredientes
    textSize(10);
    fill(0);
    text(ingredientesColetados[i], 50 + i * 40, height - 60);
  }

  // Botão para "Finalizar Prato"
  fill(0, 150, 0);
  rect(width - 150, height - 50, 100, 40);
  fill(255);
  textSize(18);
  text('Finalizar', width - 100, height - 25);
}

function desenhaTelaFim() {
  background(255, 255, 200); // Fundo claro
  textAlign(CENTER, CENTER);
  textSize(40);
  fill(0);
  text('Parabéns! Seu Prato Saudável!', width / 2, height / 3);

  // Exibe os ingredientes que o jogador "montou" (ou uma representação)
  // Baseado nos 'ingredientesColetados'
  // ...

  textSize(24);
  text('Pontuação Final: ' + pontuacao, width / 2, height / 2);
  textSize(18);
  text('Lembre-se: comer bem é viver melhor e valorizar nossos produtores!', width / 2, height / 2 + 50);

  // Botão para jogar novamente
  fill(0, 200, 0);
  rect(width / 2 - 75, height - 100, 150, 50);
  fill(255);
  textSize(24);
  text('Jogar Novamente', width / 2, height - 75);

  if (mouseX > width / 2 - 75 && mouseX < width / 2 + 75 &&
      mouseY > height - 100 && mouseY < height - 50 && mouseIsPressed) {
    telaAtual = 0; // Volta para o início
  }
}

function resetGame() {
  vida = 3;
  pontuacao = 0;
  frutas = [];
  obstaculos = [];
  ingredientesColetados = [];
  personagem = new Personagem(); // Reinicia a posição do personagem
}

function reiniciaFase() {
  frutas = [];
  obstaculos = [];
  // Não reseta vida e pontuação aqui, só os elementos da fase
}